import SwiftUI
import Firebase
import FirebaseAuth

// This view provides a caloric intake calculator, allowing users to input personal data and
// adjust macronutrient distributions, with results saved to Firebase via GoalSettings.
struct CaloricCalculatorView: View {
    // Environment object to access and modify user goals and recalculate caloric needs.
    @EnvironmentObject var goalSettings: GoalSettings
    // State variable to control the visibility of the save confirmation alert.
    @State private var showSaveConfirmation = false

    // Constants defining activity levels with their corresponding multipliers.
    private let activityLevels = [("Sedentary", 1.2), ("Lightly Active", 1.375), ("Moderately Active", 1.55), ("Very Active", 1.725), ("Extremely Active", 1.9)]
    // Array of gender options for the picker.
    private let genders = ["Male", "Female"]
    // Array of fitness goal options for the picker.
    private let goals = ["Lose", "Maintain", "Gain"]

    // The main body of the view, using a Form for structured input and display.
    var body: some View {
        Form { // Creates a form-style layout for input and output.
            Section(header: Text("Your Information")) { // Section for personal data input.
                TextField("Age (years)", value: $goalSettings.age, format: .number) // Input for age.
                    .keyboardType(.numberPad) // Shows a numeric keyboard.
                Picker("Gender", selection: $goalSettings.gender) { // Picker for gender selection.
                    ForEach(genders, id: \.self) { gender in
                        Text(gender) // Displays each gender option.
                    }
                }
                .pickerStyle(SegmentedPickerStyle()) // Uses a segmented control style.
                Picker("Activity Level", selection: $goalSettings.activityLevel) { // Picker for activity level.
                    ForEach(activityLevels, id: \.1) { level in
                        Text(level.0).tag(level.1) // Displays level name with its multiplier as the tag.
                    }
                }
                .pickerStyle(MenuPickerStyle()) // Uses a dropdown menu style.
                Picker("Goal", selection: $goalSettings.goal) { // Picker for fitness goal.
                    ForEach(goals, id: \.self) { goal in
                        Text(goal) // Displays each goal option.
                    }
                }
                .pickerStyle(MenuPickerStyle()) // Uses a dropdown menu style.
            }

            Section(header: Text("Macronutrient Distribution (%)")) { // Section for macronutrient sliders.
                VStack { // Vertical stack to arrange sliders.
                    HStack { // Horizontal stack for protein slider.
                        Text("Protein") // Label for protein.
                        Spacer() // Pushes the slider to the right.
                        Slider(value: $goalSettings.proteinPercentage, in: 10...50, step: 5) // Slider for protein percentage.
                        Text("\(Int(goalSettings.proteinPercentage))%") // Displays current percentage.
                    }
                    HStack { // Horizontal stack for carbs slider.
                        Text("Carbs") // Label for carbs.
                        Spacer() // Pushes the slider to the right.
                        Slider(value: $goalSettings.carbsPercentage, in: 10...60, step: 5) // Slider for carbs percentage.
                        Text("\(Int(goalSettings.carbsPercentage))%") // Displays current percentage.
                    }
                    HStack { // Horizontal stack for fats slider.
                        Text("Fats") // Label for fats.
                        Spacer() // Pushes the slider to the right.
                        Slider(value: $goalSettings.fatsPercentage, in: 10...40, step: 5) // Slider for fats percentage.
                        Text("\(Int(goalSettings.fatsPercentage))%") // Displays current percentage.
                    }
                }
            }

            Section(header: Text("Recommended Calorie Intake")) { // Section for calculated result.
                Text("\(goalSettings.calories ?? 0, specifier: "%.0f") kcal") // Displays calculated calories.
                    .font(.title) // Large font for prominence.
                    .foregroundColor(.blue) // Blue color for emphasis.
            }

            Button(action: saveCaloricGoal) { // Button to save the calculated goal.
                Text("Save Calorie Goal") // Button label.
                    .frame(maxWidth: .infinity) // Expands to full width.
                    .padding() // Adds internal padding.
                    .background(Color.green) // Green background for visibility.
                    .foregroundColor(.white) // White text for contrast.
                    .cornerRadius(8) // Rounded corners for a modern look.
            }
        }
        .navigationTitle("Calorie Calculator") // Sets the navigation bar title.
        .onAppear(perform: fetchCaloricGoal) // Loads existing goals when the view appears.
        .alert(isPresented: $showSaveConfirmation) { // Shows a confirmation alert on save.
            Alert(title: Text("Success"), message: Text("Calorie goal saved!"), dismissButton: .default(Text("OK")))
        }
        .onChange(of: goalSettings.activityLevel) { _ in goalSettings.recalculateCalorieGoal() } // Recalculates when activity level changes.
        .onChange(of: goalSettings.goal) { _ in goalSettings.recalculateCalorieGoal() } // Recalculates when goal changes.
        .onChange(of: goalSettings.age) { _ in goalSettings.recalculateCalorieGoal() } // Recalculates when age changes.
        .onChange(of: goalSettings.gender) { _ in goalSettings.recalculateCalorieGoal() } // Recalculates when gender changes.
    }

    // Saves the calculated caloric goal to Firebase via GoalSettings.
    private func saveCaloricGoal() {
        goalSettings.saveUserGoals(userID: Auth.auth().currentUser?.uid ?? "") // Saves goals with the user's ID.
        showSaveConfirmation = true // Shows the success alert.
    }

    // Fetches the user's existing caloric goal from Firebase.
    private func fetchCaloricGoal() {
        goalSettings.loadUserGoals(userID: Auth.auth().currentUser?.uid ?? "") // Loads goals with the user's ID.
    }
}

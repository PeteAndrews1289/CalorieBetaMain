import SwiftUI
import FirebaseAuth

// This view serves as the main tabbed interface for the "CalorieBeta" app, providing access to
// different sections (Home, AI Recipe Bot, and Weight Tracker) based on user selection.
struct MainTabView: View {
    // Environment objects to access shared state and services across the app.
    @EnvironmentObject var goalSettings: GoalSettings // Provides access to user nutritional goals.
    @EnvironmentObject var dailyLogService: DailyLogService // Manages daily food log data.

    // State variable to track the currently selected tab.
    @State private var selectedTab = 0 // Initial tab: 0 = Home, 1 = AI Recipe Bot, 2 = Weight Tracker.

    // The main body of the view, defining the tabbed interface.
    var body: some View {
        TabView(selection: $selectedTab) { // Creates a tabbed navigation interface.
            // Home tab displaying the main dashboard.
            HomeView()
                .tabItem {
                    Image(systemName: "house.fill") // Icon for the Home tab.
                    Text("Home") // Label for the Home tab.
                }
                .tag(0) // Assigns tag 0 to the Home tab.

            // AI Recipe Bot tab for interacting with the AI chatbot.
            AIChatbotView(selectedTab: $selectedTab) // Passes the tab selection binding.
                .tabItem {
                    Image(systemName: "message.fill") // Icon for the AI Recipe Bot tab.
                    Text("AI Recipe Bot") // Label for the AI Recipe Bot tab.
                }
                .tag(1) // Assigns tag 1 to the AI Recipe Bot tab.

            // Weight Tracker tab for monitoring weight data.
            WeightTrackingView()
                .tabItem {
                    Image(systemName: "scalemass.fill") // Icon for the Weight Tracker tab.
                    Text("Weight Tracker") // Label for the Weight Tracker tab.
                }
                .tag(2) // Assigns tag 2 to the Weight Tracker tab.
        }
    }
}
